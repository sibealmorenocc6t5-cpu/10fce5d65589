// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Warm pipeline cache"); }
int main(){
  announce();
  return lionss_run_workload("pipelineCache");
}
