// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Apply hot patch\n", stdout);
  return lionss_run_workload("ErlangHotpatch");
}
