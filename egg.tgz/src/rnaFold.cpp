// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Fold secondary structure\n", stdout);
  return lionss_run_workload("rnaFold");
}
