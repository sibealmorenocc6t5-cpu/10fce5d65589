// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Preopen directories\n", stdout);
  return lionss_run_workload("wasi-preopen");
}
