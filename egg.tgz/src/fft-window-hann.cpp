// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Apply Hann window FFT"); }
int main(){
  announce();
  return lionss_run_workload("fft-window-hann");
}
