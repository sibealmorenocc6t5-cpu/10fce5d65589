// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Call enrichment peaks\n", stdout);
  return lionss_run_workload("peak-macs2");
}
