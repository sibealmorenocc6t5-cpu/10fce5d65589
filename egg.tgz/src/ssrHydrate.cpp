// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Hydrate shell\n", stdout);
  return lionss_run_workload("ssrHydrate");
}
